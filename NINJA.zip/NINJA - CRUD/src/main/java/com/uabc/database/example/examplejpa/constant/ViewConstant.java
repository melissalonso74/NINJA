package com.uabc.database.example.examplejpa.constant;

public class ViewConstant {
    public static final String CONTACT_FORM = "contactform";
    public static final String CONTACTS = "contacts";

    public static final String LOG_FORM = "logform";
    public static final String LOGS = "logs";

    public static final String USER_FORM = "userform";
    public static final String USERS = "users";

    public static final String USERROLE_FORM = "userroleform";
    public static final String USERROLES = "userroles";


}
