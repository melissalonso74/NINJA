package com.uabc.database.example.examplejpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamplejpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamplejpaApplication.class, args);
	}

}
